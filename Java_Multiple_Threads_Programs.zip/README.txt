Java Multiple Threads Program

Files:
1. Method1_ThreadClass.java - uses classes that extend Thread.
2. Method2_RunnableInterface.java - uses classes that implement Runnable.

To run either program:
1. Rename the selected .java file to Main.java (because the public class is Main).
2. Open a terminal in that folder.
3. Compile: javac Main.java
4. Run: java Main

The programs run indefinitely. Stop with Ctrl+C in the terminal.
Output order may vary because the threads run concurrently.
